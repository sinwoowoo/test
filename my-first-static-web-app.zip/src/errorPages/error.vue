<template>
	<div class="page-contents">
		<div class="container"></div>
			<h1><span class="kt-red-text">잘못된 접근</span> 또는 <span class="kt-red-text">존재하지 않는 페이지</span>입니다.</h1>
			<h1> 잠시후 재시도 해주시기 바랍니다. </h1>
		</div>
	</div>
</template>

<script>
export default {
	name: 'ErrorPage',
	// Add any necessary component options here
}
</script>

<style>
/* Add any necessary styles here */
</style>
