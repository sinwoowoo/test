﻿<template>
  <div>
    <form name="pageForm" action="" method="post">
      <input type="hidden" :value="csrfToken" name="request_token" />
      <input type="hidden" :value="requestUrl" name="request_url" />
      <input type="hidden" value="" name="pageType" />
    </form>
    <form id="topMenuForm" name="topMenuForm" method="post">
      <input type="hidden" name="user_id" :value="userId" />
      <input type="hidden" :value="csrfToken" name="request_token" />
      <input type="hidden" :value="requestUrl" name="request_url" />
    </form>
    <form id="sessionForm" name="sessionForm" method="post">
      <input type="hidden" name="user_id" :value="userId" />
      <input type="hidden" :value="csrfToken" name="request_token" />
      <input type="hidden" :value="requestUrl" name="request_url" />
    </form>
    <header id="header">
      <div class="container">
        <div class="kt-egov-logo">
          <a href="javascript:menuMove('/main.do')">
            <img src="/images/kt_egov_logo_new.png" alt="kt국가정보통신서비스" />
            <img src="/images/kt_egov_logo_mobile_new.png" alt="kt국가정보통신서비스" class="mobile" />
          </a>
        </div>
        <a href="javascript:" class="hamberger-btn">
          <i class="material-icons">&#xE5D2;</i>
        </a>
        <div class="mini">
          <a href="javascript:" class="account-btn">
            <i class="material-icons">&#xE851;</i>
          </a>
          <ul>
            <li v-if="userId">
              <a href="javascript:menuMove2('/member/logout.do')">LOGOUT</a>
              <template v-if="userAuthId === '40'">
                <li>
                  <a href="javascript:menuMove2('/member/member_list.do')">관리자</a>
                </li>
              </template>
              <li>
                <a href="javascript:menuMove2('/member/member_edit2.do')">MY Info</a>
              </li>
              <li>
                <a href="javascript:menuMove2('/member/member_delete.do')">회원탈퇴</a>
              </li>
            </li>
            <li v-else>
              <a href="javascript:menuMove2('/member/login.do')">LOGIN</a>
              <li>
                <a href="javascript:menuMove2('/member/check_member.do')">JOIN US</a>
              </li>
            </li>
          </ul>
        </div>
      </div>
      <nav class="gnb">
        <ul>
          <li>
            <a href="javascript:">제도소개</a>
            <div class="submenu intro">
              <div class="container">
                <div class="menu-title">
                  <h3>제도소개</h3>
                  <p>kt그룹 국가정보통신서비스<br />제도소개 입니다.</p>
                </div>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/intro/definition.do')">정의</a>
                  </dt>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/intro/feature.do')">특징</a>
                  </dt>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/intro/service.do')">서비스체계</a>
                  </dt>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/intro/changepoint.do')">제도변경사항</a>
                  </dt>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/intro/counsel.do')">추진체계</a>
                  </dt>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/intro/propulsion.do')">추진경과</a>
                  </dt>
                </dl>
              </div>
            </div>
          </li>

          <li>
            <a href="javascript:">kt그룹서비스</a>
            <div class="submenu service"></div>
              <div class="container">
                <div class="menu-title">
                  <h3>kt그룹 서비스</h3>
                  <p>kt그룹 국가정보통신서비스<br />입니다.</p>
                </div>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/service/ktservice.do', 1)">A. 전용회선서비스</a>
                  </dt>
                  <dd>
                    <a href="javascript:menuMove('/service/leased_basic.do')">기본회선서비스</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/service/leased_backbone.do')">백본회선서비스</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/service/leasedline_infra.do')">전용회선 인프라</a>
                  </dd>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/service/ktservice.do', 2)">B. 인터넷서비스</a>
                  </dt>
                  <dd>
                    <a href="javascript:menuMove('/service/ipservice_internet.do')">인터넷서비스</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/service/ipservice_infra.do')">인터넷 인프라</a>
                  </dd>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/service/ktservice.do', 3)">C .인터넷전화서비스</a>
                  </dt>
                  <dd>
                    <a href="javascript:menuMove('/service/ipservice_soip.do')">인터넷전화서비스</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/service/wireless_m_internetphone.do')">모바일행정전화 서비스</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/service/ipservice_soip_infra.do')">인터넷 전화 인프라</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/service/wireless_m_internetphone_infra.do')">모바일행정전화 인프라</a>
                  </dd>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/service/ktservice.do', 4)">D. 무선서비스</a>
                  </dt>
                  <dd>
                    <a href="javascript:menuMove('/service/wireless_data.do')">무선데이터서비스</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/service/iot_service.do')">IoT서비스</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/service/wireless_infra.do')">무선 인프라</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/service/iot_infra.do')">IoT 인프라</a>
                  </dd>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/service/ktservice.do', 5)">E. CCTV서비스</a>
                  </dt>
                  <dd>
                    <a href="javascript:menuMove('/service/leased_cctv.do')">CCTV 전송회선 서비스</a>
                  </dd>
                </dl>
              </div>
            </div>
          </li>

          <li>
            <a href="javascript:">이용안내</a>
            <div class="submenu guide">
              <div class="container">
                <div class="menu-title"></div>
                  <h3>이용안내</h3>
                  <p>kt그룹 국가정보통신서비스<br />이용안내 입니다.</p>
                </div>
                <dl>
                  <dt>
                    <a href="javascript:">이용절차</a>
                  </dt>
                  <dd>
                    <a href="javascript:menuMove('/guide/procedure.do')">이용절차</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/guide/procedure1.do')">청약절차</a>
                  </dd>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:">요금정보</a>
                  </dt>
                  <dd>
                    <a href="javascript:menuMove('/guide/charges.do')">요금표</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/guide/area.do')">권역/거리/속도체계</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/charge/reckoning.do')">이용요금계산</a>
                  </dd>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/guide/counsel.do')">상담안내</a>
                  </dt>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:">운영/장애 안내</a>
                  </dt>
                  <dd>
                    <a href="javascript:menuMove('/guide/kt_merit.do')">KT특장점</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/guide/ktsat_merit.do')">KTsat특장점</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/guide/formation.do')">조직/체계</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/guide/hindrance.do')">장애대응 방안</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/guide/control.do')">망관리/감시</a>
                  </dd>
                </dl>
              </div>
            </div>
          </li>

          <li>
            <a href="javascript:">트래픽조회</a>
            <div class="submenu traffic">
              <div class="container">
                <div class="menu-title"></div>
                  <h3>트래픽조회</h3>
                  <p>kt그룹 국가정보통신서비스<br />트래픽조회 입니다.</p>
                </div>
                <dl>
                  <dt>
                    <a href="javascript:">트래픽조회 서비스</a>
                  </dt>
                  <dd>
                    <a href="javascript:menuMove('/traffic/traffic1.do')">회선조회</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/traffic/traffic2.do')">트래픽조회</a>
                  </dd>
                  <dd>
                    <a href="javascript:menuMove('/traffic/traffic3.do')">그래프</a>
                  </dd>
                </dl>
              </div>
            </div>
          </li>

          <li>
            <a href="javascript:">고객지원</a>
            <div class="submenu support">
              <div class="container"></div>
                <div class="menu-title">
                  <h3>고객지원</h3>
                  <p>kt그룹 국가정보통신서비스<br />고객지원 입니다.</p>
                </div>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/support/notice_list.do')">공지사항</a>
                  </dt>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/support/dataroom_list.do')">자료실</a>
                  </dt>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/support/faq.do')">FAQ</a>
                  </dt>
                </dl>
                <dl>
                  <dt>
                    <a href="javascript:menuMove('/member/agreement.do')">홈페이지 이용약관</a>
                  </dt>
                </dl>
                <dl>
                  <dt></dt>
                    <a href="javascript:menuMove('/member/personal.do')">개인정보처리방침</a>
                  </dt>
                </dl>
              </div>
            </div>
          </li>
        </ul>
      </nav>
    </header>
  </div>
</template>

<script>
export default {
  data() {
    return {
      csrfToken: '<%=request.getSession().getAttribute("CSRF_TOKEN")%>',
      requestUrl: '<%=request.getScheme()%>://<%=request.getServerName()%>:<%=request.getServerPort()%><%=request.getAttribute("javax.servlet.forward.request_uri")%>',
      userId: '<%=request.getSession().getAttribute("user_id") %>',
      userAuthId: '<%=request.getSession().getAttribute("user_auth_id") %>'
    };
  }
};
</script>

<style>
/* Add your styles here */
</style>
