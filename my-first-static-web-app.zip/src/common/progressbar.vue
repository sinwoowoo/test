<template>
	<div id="progressbar" class="row" style="position:absolute; width:1100px; height:750px; background: white; opacity: 0.7; z-index: 999999; display: none;">
		<div style="margin-top:30%; text-align: center;">
			<img src="~/images/bx_loader.gif" alt="로딩중"/>
			<p>조회중 입니다.</p>
		</div>
	</div>
</template>
