<template>
    <html>
        <head>
            <meta charset="UTF-8">
            <title>Page</title>
        </head>
        <body>
            <!-- Your content here -->
        </body>
    </html>
</template>

<script>
export default {
    name: 'Page',
    // Your Vue component logic here
}
</script>

<style scoped>
/* Your component-specific styles here */
</style>