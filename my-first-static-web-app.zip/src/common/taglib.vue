<template>
    <!-- Your Vue template code here -->
</template>

<script>
import Vue from 'vue';

// Import the required libraries
import 'jsp/jstl/core';
import 'jsp/jstl/functions';
import 'jsp/jstl/fmt';
import 'spring/tags';
import 'WEB-INF/tld/paging-taglib.tld';

export default {
    // Your Vue component options here
}
</script>

<style>
/* Your component styles here */
</style>