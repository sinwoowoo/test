<template>
    <div>
        <link type="text/css" rel="stylesheet" :href="`${pageContext.request.contextPath}/css/kt_egov_new.css?ver=0.1`" />
        <link type="text/css" rel="stylesheet" :href="`${pageContext.request.contextPath}/css/jquery-ui.css`" />
        <link type="text/css" rel="stylesheet" :href="`${pageContext.request.contextPath}/css/captcha.css`" />
    </div>
</template>